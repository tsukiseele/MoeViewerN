require('./check-engines')
process.env.NODE_ENV = 'production'
require('./index')
