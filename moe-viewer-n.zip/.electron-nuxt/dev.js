require('./check-engines')
process.env.NODE_ENV = 'development'
require('./index')
